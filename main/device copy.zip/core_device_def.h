#ifndef CORE_DEVICE_DEF_H
#define CORE_DEVICE_DEF_H

#ifdef __cplusplus
extern "C" {
#endif // __cplusplus

typedef enum UnitKind {
    UnitKind_Idu = 0,
    UnitKind_Odu,
    UnitKind_Max
} UnitKind;

#ifdef __cplusplus
} // extern "C"
#endif // __cplusplus

#endif // CORE_DEVICE_DEF_H
