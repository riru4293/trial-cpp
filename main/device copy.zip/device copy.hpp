#pragma once

#include <cstring>
#include <forward_list>
#include <memory>

namespace device
{
    class Unit
    {
    public:
        enum class Kind : uint8_t { IDU, ODU };

        constexpr Unit(const Kind kind, const uint8_t index) noexcept : kind_(kind), index_(index) {}

        constexpr Kind kind() const noexcept { return kind_; }
        constexpr uint8_t index() const noexcept { return index_; }

        constexpr bool operator==(const Unit &o) const noexcept {
            return kind_ == o.kind_ && index_ == o.index_;
        }
        constexpr bool operator!=(const Unit &o) const noexcept { return !(*this == o); }
    private:
        const Kind kind_;
        const uint8_t index_;
    };

    class Util
    {
    public:
        bool resolveInstanceId(const Unit &unit, const uint16_t eid, const uint8_t pid, uint16_t &iid) const noexcept;
    };

    class PropertyKey
    {
    public:
        static std::unique_ptr<PropertyKey> create11(const Unit &unit, uint16_t eid, uint8_t pid) noexcept {
            uint16_t resolved_iid = 0U; // TODO
            return Util().resolveInstanceId(unit, eid, pid, resolved_iid)
                ? std::unique_ptr<PropertyKey>(new PropertyKey(unit, eid, resolved_iid, pid))
                : nullptr;
        }

        constexpr Unit unit() const noexcept { return unit_; }
        constexpr uint16_t eid() const noexcept { return eid_; }
        constexpr uint16_t iid() const noexcept { return iid_; }
        constexpr uint8_t pid() const noexcept { return pid_; }

        constexpr bool operator==(const PropertyKey& o) const noexcept {
            return unit_ == o.unit_ && eid_ == o.eid_ && iid_ == o.iid_ && pid_ == o.pid_;
        }
        constexpr bool operator!=(const PropertyKey& o) const noexcept { return !(*this == o); }

    private:
        constexpr PropertyKey(const Unit& unit, const uint16_t eid, const uint16_t iid, const uint8_t pid) noexcept
            : unit_(unit), eid_(eid), iid_(iid), pid_(pid) {}
        const Unit unit_;
        const uint16_t eid_;
        const uint16_t iid_;
        const uint8_t pid_;
    };

    class PropertyValue
    {
    public:
        static std::unique_ptr<PropertyValue> create11(uint8_t const n, const uint8_t* const data) noexcept {
            return !(n < 1 || n > 32 || data == nullptr) // TODO
                ? std::unique_ptr<PropertyValue>(new PropertyValue(n, data))
                : nullptr;
        }

        uint8_t size() const noexcept { return size_; }
        const uint8_t* data() const noexcept { return data_; }

        bool operator==(const PropertyValue& o) const noexcept
        {
            return (size_ == o.size_) && std::memcmp(data_, o.data_, size_) == 0;
        }
        bool operator!=(const PropertyValue& o) const noexcept { return !(*this == o); }
    private:
        PropertyValue( uint8_t const n, const uint8_t* const data ) noexcept : size_(n), data_(data) {}

        const uint8_t size_;
        const uint8_t* const data_;
    };

    class PropertyValueListBuilder
    {
    public:
        static constexpr int8_t MAX_SIZE = 20U;

        inline PropertyValueListBuilder( const Unit &unit ) noexcept : unit_( unit ) {}

        uint8_t size( void )
        {
            return size_;
        }

        template <size_t N>
        bool append(const uint16_t eid, const uint8_t pid, const uint8_t (&data)[N]) {
            static_assert(N <= 255, "data size must be <= 255");
            return append(eid, pid, static_cast<uint8_t>(N), data);
        }

        bool append( const uint16_t eid, const uint8_t pid, const uint8_t n, const uint8_t *data )
        {
            if ( size_ >= MAX_SIZE) { return false; }

            std::unique_ptr<PropertyKey> key_ptr = PropertyKey::create11( unit_, eid, pid );
            if ( key_ptr == nullptr ) { return false; }

            std::unique_ptr<PropertyValue> value_ptr = PropertyValue::create11( n, data );
            if ( value_ptr == nullptr ) { return false; }

            last_ = items_.insert_after( last_, std::pair<PropertyKey, PropertyValue>{ *key_ptr, *value_ptr } );
            ++size_;

            return true;
        }

        bool append( const PropertyKey &key, const PropertyValue &value )
        {
            if ( size_ >= MAX_SIZE) { return false; }

            // 末尾に追加 (last_ を保持して O(1) で追加)
            last_ = items_.insert_after( last_, std::pair<PropertyKey, PropertyValue>{ key, value } );
            ++size_;

            return true;
        }

        std::forward_list<std::pair<PropertyKey, PropertyValue>> build()
        {
            return std::move( items_ );
        }
    private:
        const Unit unit_;
        std::forward_list<std::pair<PropertyKey, PropertyValue>> items_;
        std::forward_list<std::pair<PropertyKey, PropertyValue>>::iterator last_ = items_.before_begin();
        uint8_t size_ = 0U;
    };

} // namespace device
