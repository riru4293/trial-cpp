#include <device.hpp>

using namespace device;

// static void doX( Unit unit, uint16_t eid, uint16_t iid, uint8_t pid, const uint8_t* data, uint8_t data_size ) {
// }

// void test() {
//     Unit unit(Unit::Kind::IDU, 0U);
//     uint16_t eid = 100U;
//     uint8_t pid = 1U;

//     auto maybeKey = PropertyKey::create11(unit, eid, pid);

//     auto builder = PropertyValueListBuilder(unit);
//     std::array<uint8_t,3> data = {1,2,3};
//     // append from C-array
//     builder.append(eid, pid, data);

//     // append using an optional property value and key
//     if (maybeKey) {
//         if (auto maybeVal = PropertyValue::create11(static_cast<uint8_t>(std::size(data)), data)) {
//             builder.append(*maybeKey, *maybeVal);
//         }
//     }

//     // append from fixed arrays
//     builder.append(eid, pid, std::array<uint8_t,4>{ 0x01, 0x02, 0x03, 0x04 });
//     builder.append(eid, pid, std::array<uint8_t,4>{ 0x01, 0x02, 0x03, 0x04 });

//     // build() is rvalue-qualified for efficient move
//     auto list = std::move(builder).build();
    
//     for(const auto& v : list) {
//         auto span = v.second.data();
//         doX(v.first.unit(), v.first.eid(), v.first.iid(), v.first.pid(), span.data(), static_cast<uint8_t>(span.size()));
//     }
// }
