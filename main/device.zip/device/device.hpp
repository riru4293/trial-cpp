#pragma once

#include <cstdint>
#include <cstring>
#include <optional>
#include <cstddef>
#include <ostream>
#include <string>
#include <format>
#include <string_view>

namespace device
{
    /**
     * @brief Represents a device unit (IDU, ODU, etc).
     * @details
     * Unit represents an unit within a device.
     * @code
     * +-------------------+
     * |      Device       |
     * +===================+
     * |  +-------------+  |
     * |  |    Unit[]   |  |
     * |  +=============+  |
     * |  |    Kind     |  |
     * |  +-------------+  |
     * |  |    Index    |  |
     * |  +-------------+  |
     * +-------------------+
     * @endcode
     */
    class Unit
    {
    /* ^\__________________________________________ */
    /* Static members, Inner types.                 */
    public:
        constexpr static std::uint8_t PRIMARY_IDX = 0; //!< Primary unit index.
        /**
         * @brief Unit kind.
         */
        enum class Kind : std::uint8_t
        {
            InDoor, //!< In door unit
            OutDoor //!< Out door unit
        };
    /* ^\__________________________________________ */
    /* Constructors, Operators.                     */
    public:
        /**
         * @brief Construct with given kind and index.
         * @param kind Unit kind.
         * @param index Unit index. 0 is primary unit. 1 or greater is sub units.
         */
        explicit constexpr Unit(const Kind kind, const std::uint8_t index) noexcept
            : kind_(kind), index_(index) {}
        ~Unit() noexcept = default;                       //!< Destructor (default).
        Unit(const Unit &) noexcept = default;            //!< Copy constructor (default).
        Unit &operator=(const Unit &) noexcept = delete;  //!< Copy operator (deleted).
        Unit(Unit &&) noexcept = delete;                  //!< Move constructor (deleted).
        Unit &operator=(Unit &&) noexcept = delete;       //!< Move operator (deleted).
        constexpr bool operator==(const Unit &) const noexcept = default;   //!< Equality operator (default).
        constexpr auto operator<=>(const Unit &) const noexcept = default;  //!< Three-way comparison operator (default).
    /* ^\__________________________________________ */
    /* Instance members.                            */
    public:
        [[nodiscard]] constexpr Kind kind() const noexcept { return kind_; }
        [[nodiscard]] constexpr std::uint8_t index() const noexcept { return index_; }
    private:
        const Kind kind_;
        const std::uint8_t index_;
    };

    class InstanceKey
    {
    /* ^\__________________________________________ */
    /* Static members, Inner types.                 */
    public:
        constexpr static std::uint8_t PRIMARY_IDX = 0; //!< Primary instance index.
    /* ^\__________________________________________ */
    /* Constructors, Operators.                     */
    public:
        explicit constexpr InstanceKey(const Unit unit, const std::uint16_t entityId, const std::uint8_t propertyId) noexcept
            : InstanceKey(unit, entityId, propertyId, PRIMARY_IDX) {}
        explicit constexpr InstanceKey(const Unit unit, const std::uint16_t entityId, const std::uint8_t propertyId, const std::uint8_t index) noexcept
            : unit_(unit), entityId_(entityId), propertyId_(propertyId), index_(index) {}
        ~InstanceKey() noexcept = default;                                         //!< Destructor (default).
        InstanceKey(const InstanceKey &) noexcept = default;                       //!< Copy constructor (default).
        InstanceKey &operator=(const InstanceKey &) noexcept = delete;             //!< Copy operator (deleted).
        InstanceKey(InstanceKey &&) noexcept = delete;                             //!< Move constructor (deleted).
        InstanceKey &operator=(InstanceKey &&) noexcept = delete;                  //!< Move operator (deleted).
        constexpr bool operator==(const InstanceKey &) const noexcept = default;   //!< Equality operator (default).
        constexpr auto operator<=>(const InstanceKey &) const noexcept = default;  //!< Three-way comparison operator (default).
    /* ^\__________________________________________ */
    /* Instance members.                            */
    public:
        [[nodiscard]] constexpr Unit unit() const noexcept { return unit_; }
        [[nodiscard]] constexpr std::uint16_t entityId() const noexcept { return entityId_; }
        [[nodiscard]] constexpr std::uint8_t propertyId() const noexcept { return propertyId_; }
        [[nodiscard]] constexpr std::uint8_t index() const noexcept { return index_; }
    private:
        Unit unit_;
        std::uint16_t entityId_;
        std::uint8_t propertyId_;
        std::uint8_t index_;
    };

    

    namespace util
    {
        class InstanceIdResolver
        {
        /* ^\__________________________________________ */
        /* Constructors, Operators.                     */
        public:
            explicit constexpr InstanceIdResolver() noexcept = default;                     //!< Constructor (default).
            ~InstanceIdResolver() noexcept = default;                                       //!< Destructor (default).
            InstanceIdResolver(const InstanceIdResolver &) noexcept = delete;               //!< Copy constructor (deleted).
            InstanceIdResolver &operator=(const InstanceIdResolver &) noexcept = delete;    //!< Copy operator (deleted).
            InstanceIdResolver(InstanceIdResolver &&) noexcept = delete;                    //!< Move constructor (deleted).
            InstanceIdResolver &operator=(InstanceIdResolver &&) noexcept = delete;         //!< Move operator (deleted).
            std::optional<std::uint16_t> resolveInstanceId(InstanceKey &key) const noexcept;
        };
    }

    namespace commentouted
    {
    // // Lightweight value type representing the triple (unit, eid, iid, pid).
    // class PropertyKey
    // {
    // public:
    //     // Prefer returning an optional value type instead of owning pointers.
    //     static std::optional<PropertyKey> create11(const Unit &unit, uint16_t eid, std::uint8_t pid) noexcept {
    //         uint16_t resolved_iid = 0U;
    //         if (!Util().resolveInstanceId(unit, eid, pid, resolved_iid)) {
    //             return std::nullopt;
    //         }
    //         return PropertyKey(unit, eid, resolved_iid, pid);
    //     }

    //     constexpr Unit unit() const noexcept { return unit_; }
    //     constexpr uint16_t eid() const noexcept { return eid_; }
    //     constexpr uint16_t iid() const noexcept { return iid_; }
    //     constexpr std::uint8_t pid() const noexcept { return pid_; }

    //     constexpr bool operator==(const PropertyKey& o) const noexcept = default;

    // private:
    //     constexpr PropertyKey(const Unit& unit, const uint16_t eid, const uint16_t iid, const std::uint8_t pid) noexcept
    //         : unit_(unit), eid_(eid), iid_(iid), pid_(pid) {}

    // private:
    //     Unit unit_;
    //     uint16_t eid_;
    //     uint16_t iid_;
    //     std::uint8_t pid_;
    // };

    // // Immutable, owning byte container with small static capacity for safety and locality.
    // class PropertyValue
    // {
    // public:

    //     static constexpr std::size_t MIN_BYTES = 1U;
    //     static constexpr std::size_t MAX_BYTES = 32U;

    //     static std::optional<PropertyValue> create11(const std::uint8_t n, const std::byte* const data) noexcept {
    //         if (data == nullptr || n < 1 || n > MAX_BYTES) {
    //             return std::nullopt;
    //         }
    //         PropertyValue v{};
    //         v.size_ = static_cast<std::uint8_t>(n);
    //         std::copy_n(data, v.size_, v.buffer_.begin());
    //         return v;
    //     }

    //     constexpr std::size_t size() const noexcept { return size_; }
    //     // constexpr std::span<const std::uint8_t> data() const noexcept { return
    //     //      std::span<const std::uint8_t>(buffer_.data(), static_cast<std::size_t>(size_)); }

    //     bool operator==(const PropertyValue& o) const noexcept = default;
    // private:
    //     PropertyValue() noexcept = default;

    // private:
    //     std::array<std::uint8_t, MAX_BYTES> buffer_{};
    //     std::uint8_t size_ = 0U;
    // };

    // class PropertyValueSet
    // {
    // public:
    //     using Element = std::pair<PropertyKey, PropertyValue>;

    //     static constexpr std::size_t MAX_COUNT = 20U;

    //     explicit PropertyValueSet(const Unit &unit) noexcept : unit_(unit) {}

    //     Unit unit() const noexcept { return unit_; }
    //     std::size_t size() const noexcept { return elements_.size(); }
    //     std::span<const Element> elements() const noexcept { return elements_; }

    //     template <std::size_t N>
    //     bool tryPushBack(const uint16_t eid, const std::uint8_t pid, const std::array<std::byte, N>& data) noexcept
    //     {
    //         return tryPushBack(eid, pid, data.size(), data.data());
    //     }

    //     bool tryPushBack(const uint16_t eid, const std::uint8_t pid, const std::size_t data_bytes, const std::byte*const data) noexcept
    //     {
    //         if (   data == nullptr
    //             || data_bytes < PropertyValue::MIN_BYTES
    //             || data_bytes > PropertyValue::MAX_BYTES) {
    //             return false;
    //         }

    //         std::span<const std::byte> data_span{data, data_bytes};

    //         return tryPushBack(eid, pid, data_span);
    //     }

    //     bool tryPushBack(const uint16_t eid, const std::uint8_t pid,const std::span<const std::byte> data) noexcept
    //     {

    //         auto maybe_key = PropertyKey::create11(unit_, eid, pid);
    //         if (!maybe_key) return false;

    //         auto maybe_value = PropertyValue::create11(static_cast<std::uint8_t>(data.size()), data.data());
    //         if (!maybe_value) return false;

    //         return tryPushBack(*maybe_key, *maybe_value);
    //     }

    //     bool tryPushBack(const PropertyKey &key, const PropertyValue &value) noexcept
    //     {
    //         if (elements_.size() >= MAX_COUNT) return false;

    //         (void)elements_.emplace_back(key, value);
    //         return true;
    //     }
    // private:
    //     Unit unit_;
    //     std::vector<Element> elements_;
    // };
    } // namespace commentouted

    /* ^\__________________________________________ */
    /* Namespace members (device)                   */
    using UnitKind = Unit::Kind;
    constexpr Unit PRIMARY_IDU{UnitKind::InDoor, PRIMARY_IDX};
    constexpr Unit PRIMARY_ODU{UnitKind::OutDoor, PRIMARY_IDX};

    std::ostream &operator<<(std::ostream &os, const UnitKind &v)
    {
        switch (v)
        {
            case UnitKind::InDoor:  os << "InDoor";  break;
            case UnitKind::OutDoor: os << "OutDoor"; break;
            default:                os << "Unknown"; break;
        }

        os << "(" << static_cast<int>(v) << ")";

        return os;
    }

    std::ostream &operator<<(std::ostream &os, const Unit &v)
    {
        os << "Unit{kind=" << v.kind() << ", index=" << static_cast<int>(v.index()) << "}";
        return os;
    }

    std::ostream &operator<<(std::ostream &os, const InstanceKey &v)
    {
        os << "InstanceKey{unit=" << v.unit()
           << ", entityId=" << v.entityId()
           << ", propertyId=" << static_cast<int>(v.propertyId())
           << ", index=" << static_cast<int>(v.index()) << "}";
        return os;
    }
} // namespace device

namespace std {
    template <>
    struct hash<device::Unit> {
        size_t operator()(const device::Unit& u) const noexcept {
            // kind と index を組み合わせてハッシュ化
            return (static_cast<size_t>(u.kind()) << 8) ^ static_cast<size_t>(u.index());
        }
    };
}

namespace std {
    template <>
    struct hash<device::InstanceKey> {
        size_t operator()(const device::InstanceKey& k) const noexcept {
            // 複数フィールドを組み合わせてハッシュ化
            size_t h1 = std::hash<device::Unit>{}(k.unit());
            size_t h2 = std::hash<std::uint16_t>{}(k.entityId());
            size_t h3 = std::hash<std::uint8_t>{}(k.propertyId());
            size_t h4 = std::hash<std::uint8_t>{}(k.index());
            // シンプルに XOR で混ぜる
            return (((h1 ^ (h2 << 1)) >> 1) ^ (h3 << 1)) ^ (h4 << 2);
        }
    };
}


//     inline std::string_view to_string(UnitKind v) {
//         switch (v) {
//             case UnitKind::InDoor:  return "InDoor";
//             case UnitKind::OutDoor: return "OutDoor";
//             default:                return "Unknown UnitKind";
//         }
//     }
// namespace std {
//     inline ostream& operator<<(ostream& os, const UnitKind& v) {
//         os << to_string(v) << "(" << static_cast<uint8_t>(v) << ")";
//         return os;
//     }
// }
// namespace std {
//     template <>
//     struct formatter<UnitKind, char> {
//         constexpr auto parse(format_parse_context& ctx) { return ctx.begin(); }

//         auto format(UnitKind v, format_context& ctx) const {
//             return format_to(ctx.out(), "{}({})", to_string(v), static_cast<uint8_t>(v));
//         }
//     };
// }

// namespace std
// {

//     ostream &operator<<(ostream &os, const UnitKind &v)
//     {
//         switch (v)
//         {
//             case UnitKind::InDoor:
//                 os << "InDoor";
//                 break;
//             case UnitKind::OutDoor:
//                 os << "OutDoor";
//                 break;
//             default:
//                 os << "Unknown UnitKind(" << static_cast<uint8_t>(v) << ")";
//                 break;
//         }
//         return os;
//     }

//     template <>
//     struct formatter<UnitKind, char>
//     {
//         constexpr auto parse(format_parse_context &ctx) { return ctx.begin(); }

//         auto format(UnitKind v, format_context &ctx) const
//         {
//             switch (v)
//             {
//                 case UnitKind::InDoor:
//                     return format_to(ctx.out(), "InDoor");
//                 case UnitKind::OutDoor:
//                     return format_to(ctx.out(), "OutDoor");
//                 default:
//                     return format_to(ctx.out(), "Unknown UnitKind({})", static_cast<uint8_t>(v));
//             }
//         }
//     };

//     ostream& operator<<(ostream &os, const Unit &v) {
//         return os << "Unit{kind=" << v.kind()
//                 << ", index=" << v.index() << "}";
//     }

//     ostream& operator<<(ostream &os, const InstanceKey &v) {
//         return os << "InstanceKey{unit=" << v.unit()
//                 << ", entityId=" << v.entityId()
//                 << ", propertyId=" << v.propertyId()
//                 << ", index=" << v.index() << "}";
//     }



//     template <>
//     struct formatter<Unit, char> {
//         constexpr auto parse(format_parse_context &ctx) { return ctx.begin(); }

//         auto format(const Unit &v, format_context &ctx) const {
//             return format_to(ctx.out(), "Unit{{kind={}, index={}}}", v.kind(), v.index());
//         }
//     };
// } // namespace std